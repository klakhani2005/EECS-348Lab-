#ifndef MATRIX_H
#define MATRIX_H

#include <cstddef>
#include <memory>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <utility>

// A simple NxN Matrix class that DOES NOT use std::vector.
// Storage is managed via a unique_ptr<T[]> for RAII.
class Matrix {
public:
    using value_type = int;

    Matrix() : n_(0), data_(nullptr) {}

    explicit Matrix(std::size_t n) : n_(n), data_(std::make_unique<value_type[]>(n*n)) {
        for (std::size_t i = 0; i < n_*n_; ++i) data_[i] = 0;
    }

    // copy ctor
    Matrix(const Matrix& other) : n_(other.n_), data_(other.n_ ? std::make_unique<value_type[]>(other.n_*other.n_) : nullptr) {
        for (std::size_t i = 0; i < n_*n_; ++i) data_[i] = other.data_[i];
    }

    // move ctor
    Matrix(Matrix&& other) noexcept : n_(other.n_), data_(std::move(other.data_)) {
        other.n_ = 0;
    }

    // copy assign
    Matrix& operator=(const Matrix& other) {
        if (this == &other) return *this;
        if (other.n_ == 0) { n_ = 0; data_.reset(); return *this; }
        if (n_ != other.n_) {
            n_ = other.n_;
            data_ = std::make_unique<value_type[]>(n_*n_);
        }
        for (std::size_t i = 0; i < n_*n_; ++i) data_[i] = other.data_[i];
        return *this;
    }

    // move assign
    Matrix& operator=(Matrix&& other) noexcept {
        if (this == &other) return *this;
        n_ = other.n_;
        data_ = std::move(other.data_);
        other.n_ = 0;
        return *this;
    }

    std::size_t size() const { return n_; }

    // element access (bounds-checked)
    value_type& at(std::size_t r, std::size_t c) {
        bounds_check(r, c);
        return data_[r*n_ + c];
    }
    const value_type& at(std::size_t r, std::size_t c) const {
        bounds_check(r, c);
        return data_[r*n_ + c];
    }

    // convenient operator() (same as at())
    value_type& operator()(std::size_t r, std::size_t c) { return at(r, c); }
    const value_type& operator()(std::size_t r, std::size_t c) const { return at(r, c); }

    // pretty print
    void print(std::ostream& os = std::cout, int width = 4) const {
        for (std::size_t i = 0; i < n_; ++i) {
            for (std::size_t j = 0; j < n_; ++j) {
                os << std::setw(width) << at(i, j);
            }
            os << '\n';
        }
    }

    // Addition via operator overloading
    Matrix operator+(const Matrix& rhs) const {
        ensure_same_size(rhs);
        Matrix out(n_);
        for (std::size_t i = 0; i < n_; ++i)
            for (std::size_t j = 0; j < n_; ++j)
                out.at(i, j) = at(i, j) + rhs.at(i, j);
        return out;
    }

    // Multiplication via operator overloading
    Matrix operator*(const Matrix& rhs) const {
        ensure_same_size(rhs);
        Matrix out(n_);
        for (std::size_t i = 0; i < n_; ++i) {
            for (std::size_t j = 0; j < n_; ++j) {
                long long sum = 0;
                for (std::size_t k = 0; k < n_; ++k) {
                    sum += static_cast<long long>(at(i, k)) * rhs.at(k, j);
                }
                out.at(i, j) = static_cast<value_type>(sum);
            }
        }
        return out;
    }

    // Diagonal sums
    long long mainDiagonalSum() const {
        long long s = 0;
        for (std::size_t i = 0; i < n_; ++i) s += at(i, i);
        return s;
    }
    long long secondaryDiagonalSum() const {
        long long s = 0;
        for (std::size_t i = 0; i < n_; ++i) s += at(i, n_-1-i);
        return s;
    }
    long long bothDiagonalSum() const { return mainDiagonalSum() + secondaryDiagonalSum(); }

    // Utilities used by practices 5-7 (passed by value to avoid modifying original)
    friend Matrix swapRows(Matrix m, std::size_t r1=0, std::size_t r2=1) {
        if (m.n_ == 0) return m;
        if (r1 >= m.n_ || r2 >= m.n_) return m; // ignore invalid indices
        if (r1 == r2) return m;
        for (std::size_t j = 0; j < m.n_; ++j) {
            std::swap(m.at(r1, j), m.at(r2, j));
        }
        return m;
    }

    friend Matrix swapCols(Matrix m, std::size_t c1=0, std::size_t c2=1) {
        if (m.n_ == 0) return m;
        if (c1 >= m.n_ || c2 >= m.n_) return m;
        if (c1 == c2) return m;
        for (std::size_t i = 0; i < m.n_; ++i) {
            std::swap(m.at(i, c1), m.at(i, c2));
        }
        return m;
    }

    friend Matrix updateCell(Matrix m, std::size_t r=0, std::size_t c=0, value_type value=100) {
        if (m.n_ == 0) return m;
        if (r < m.n_ && c < m.n_) m.at(r, c) = value;
        return m;
    }

private:
    std::size_t n_;
    std::unique_ptr<value_type[]> data_;

    void bounds_check(std::size_t r, std::size_t c) const {
        if (r >= n_ || c >= n_)
            throw std::out_of_range("Matrix index out of range");
    }
    void ensure_same_size(const Matrix& rhs) const {
        if (n_ != rhs.n_)
            throw std::invalid_argument("Matrix sizes must match");
    }
};

#endif // MATRIX_H
