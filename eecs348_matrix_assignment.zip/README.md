
# EECS 348: Matrix Operations (C++)

This repository contains a complete solution that uses a custom `Matrix` class (no `std::vector`), operator overloading (`+`, `*`), and utility functions for the required practices.

## Files
- `Matrix.h` – header-only style implementation of an NxN integer matrix using `std::unique_ptr<int[]>` (not `std::vector`).
- `Matrix.cpp` – translation unit (minimal; most implementation is inline in the header).
- `main.cpp` – reads the input file, demonstrates all required operations, and prints results.
- `Makefile` – builds the project with `g++`.
- `sample_input.txt` – matches the sample in the prompt.

## Build (Cycle server)
```bash
make
```

## Run
```bash
./matrix_app sample_input.txt
```

### Optional flags
- Row swap: `--swap-rows i j`
- Column swap: `--swap-cols i j`
- Update a single cell: `--update r c value`

Example:
```bash
./matrix_app sample_input.txt --swap-rows 0 2 --swap-cols 1 3 --update 3 2 999
```

## Notes
- Matrices are stored in a single contiguous block (`unique_ptr<int[]>`). 
- Addition and multiplication use operator overloading as required.
- Row/column swap and update are implemented as **pass-by-value** helpers so the **original** matrix is not modified.
- Output uses `std::setw` for aligned columns.
