#include "Matrix.h"
// Implementation is mostly inline in the header for clarity.
// This source file exists so the build can compile multiple translation units if desired.
