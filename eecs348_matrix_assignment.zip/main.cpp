#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "Matrix.h"

/*
EECS 348 — Software Engineering I
Assignment: More C++ (classes, operator overloading, templates mention)

This program:
1) Reads two N x N matrices from a user-specified file (argv[1]).
2) Displays both matrices with aligned formatting.
3) Adds and multiplies them using overloaded operators (operator+ and operator*).
4) Computes and displays main, secondary, and combined diagonal sums.
5) Demonstrates row/column swap by value (does not mutate original).
6) Demonstrates updating a single cell by value with defaults (0,0)=100.
   Optional CLI flags allow custom indices:
     --swap-rows i j
     --swap-cols i j
     --update r c value

File format:
N
<first matrix N lines>
<second matrix N lines>

Example:
4
01 02 03 04
05 06 07 08
09 10 11 12
13 14 15 16
13 14 15 16
09 10 11 12
05 06 07 08
01 02 03 04
*/

struct Options {
    bool haveSwapRows=false, haveSwapCols=false, haveUpdate=false;
    std::size_t sr1=0, sr2=1;
    std::size_t sc1=0, sc2=1;
    std::size_t ur=0, uc=0;
    int uval=100;
};

Options parseArgs(int argc, char** argv) {
    Options opt;
    for (int i = 2; i < argc; ++i) {
        std::string flag = argv[i];
        auto need = [&](int more){ if (i+more >= argc) throw std::runtime_error("Missing arguments for " + flag); };
        if (flag == "--swap-rows") {
            need(2);
            opt.haveSwapRows = true;
            opt.sr1 = static_cast<std::size_t>(std::stoul(argv[++i]));
            opt.sr2 = static_cast<std::size_t>(std::stoul(argv[++i]));
        } else if (flag == "--swap-cols") {
            need(2);
            opt.haveSwapCols = true;
            opt.sc1 = static_cast<std::size_t>(std::stoul(argv[++i]));
            opt.sc2 = static_cast<std::size_t>(std::stoul(argv[++i]));
        } else if (flag == "--update") {
            need(3);
            opt.haveUpdate = true;
            opt.ur = static_cast<std::size_t>(std::stoul(argv[++i]));
            opt.uc = static_cast<std::size_t>(std::stoul(argv[++i]));
            opt.uval = std::stoi(argv[++i]);
        }
    }
    return opt;
}

Matrix readMatrix(std::istream& in, std::size_t n) {
    Matrix M(n);
    for (std::size_t i = 0; i < n; ++i) {
        for (std::size_t j = 0; j < n; ++j) {
            int x; 
            if (!(in >> x)) throw std::runtime_error("Failed to read matrix data");
            M.at(i, j) = x;
        }
    }
    return M;
}

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <input_file> [--swap-rows i j] [--swap-cols i j] [--update r c value]\n";
        return 1;
    }

    Options opt = parseArgs(argc, argv);

    std::ifstream fin(argv[1]);
    if (!fin) {
        std::cerr << "Error: cannot open input file '" << argv[1] << "'\n";
        return 1;
    }

    std::size_t N;
    if (!(fin >> N)) {
        std::cerr << "Error: failed to read N\n";
        return 1;
    }

    Matrix A = readMatrix(fin, N);
    Matrix B = readMatrix(fin, N);

    std::cout << "Matrix A (" << N << "x" << N << "):\n";
    A.print(std::cout, 4);
    std::cout << "\nMatrix B (" << N << "x" << N << "):\n";
    B.print(std::cout, 4);

    // Addition
    std::cout << "\nA + B:\n";
    Matrix C = A + B;
    C.print(std::cout, 4);

    // Multiplication
    std::cout << "\nA * B:\n";
    Matrix D = A * B;
    D.print(std::cout, 6); // wider cells for products

    // Diagonal sums
    std::cout << "\nDiagonal sums for A:\n"
              << "  main = " << A.mainDiagonalSum() << "\n"
              << "  secondary = " << A.secondaryDiagonalSum() << "\n"
              << "  both = " << A.bothDiagonalSum() << "\n";

    std::cout << "\nDiagonal sums for B:\n"
              << "  main = " << B.mainDiagonalSum() << "\n"
              << "  secondary = " << B.secondaryDiagonalSum() << "\n"
              << "  both = " << B.bothDiagonalSum() << "\n";

    // Practice 5 & 6: swaps (by value -> originals unchanged)
    Matrix rowswapped = opt.haveSwapRows ? swapRows(A, opt.sr1, opt.sr2) : swapRows(A);
    std::cout << "\nRow-swapped A (by value):\n";
    rowswapped.print(std::cout, 4);

    Matrix colswapped = opt.haveSwapCols ? swapCols(A, opt.sc1, opt.sc2) : swapCols(A);
    std::cout << "\nColumn-swapped A (by value):\n";
    colswapped.print(std::cout, 4);

    // Practice 7: update a single cell (by value)
    Matrix updated = opt.haveUpdate ? updateCell(A, opt.ur, opt.uc, opt.uval) : updateCell(A);
    std::cout << "\nUpdated A (by value):\n";
    updated.print(std::cout, 4);

    return 0;
}
