
#include <iostream>
#include <vector>
using namespace std;

// Original faulty function
bool faillecture(const vector<int>& attendance_records){
    int absentcount = 0;
    for(int i = 1; i < attendance_records.size(); ++i){ // BUG: starts at index 1
        absentcount += (attendance_records[i] == 0);
    }
    return absentcount >= 3;
}

void run_test(const vector<int>& rec){
    cout << "Input: ";
    for(int v : rec) cout << v << " ";
    cout << endl;
    cout << "Output (faillecture): " << faillecture(rec) << endl;
    cout << "-----------------------------" << endl;
}

int main(){
    cout << "Running all test cases..." << endl;

    run_test({1,1,1,1,1,1,1,1,1,1});               // Executes fault, no error
    run_test({0,1,1,0,1,1,1,1,1,1});               // Error state but no failure
    run_test({0,1,0,0,1,1,1,1,1,1});               // Failure
    return 0;
}
