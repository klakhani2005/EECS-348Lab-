
# Lab 13 – Debugging and Testing (Full Marks Answers)

## 1. Is there a fault in the program?
Yes.  
The fault is in the loop:

```cpp
for (int i = 1; i < attendance_records.size(); ++i)
```

It incorrectly starts iterating from index **1** instead of **0**, skipping the first lecture's attendance entirely.

---

## 2. Test case that does NOT execute the fault
Not possible.  
The faulty loop **always runs**, regardless of input.  
Therefore, **no input can avoid executing the faulty statement**.

---

## 3. Test case that executes the fault but does NOT produce an error state

### Test Case  
```
[1,1,1,1,1,1,1,1,1,1]
```

### Expected Output  
`false` (student does not fail)

### Actual Output  
`false`

### Explanation  
Index 0 is "1" (present), so skipping it does not change the absence count.  
Internal state remains correct → no error state occurs.

---

## 4. Test case that results in an error state but not a failure

### Test Case  
```
[0,1,1,0,1,1,1,1,1,1]
```

### Expected Output  
`false`

### Actual Output  
`false` (but for the wrong internal reason)

### Explanation  
Skipping index 0 (which is an absence) causes the internal count to be wrong.  
However, total real absences = 2 < 3, so final decision remains correct.

This is an **error state** but **not a failure**.

---

## 5. Test case that results in failure

### Test Case  
```
[0,1,0,0,1,1,1,1,1,1]
```

### Expected Output  
`true` (student FAILS)

### Actual Output  
`false` (student does NOT fail)

### Explanation  
Actual absences = 3, but the program counts only 2 due to skipping index 0.  
This produces an externally incorrect result → **failure**.

---
