
#include <stdio.h>

double toCelsius(double temp, char scale) {
    if (scale == 'C' || scale == 'c') return temp;
    else if (scale == 'F' || scale == 'f') return (temp - 32) * 5 / 9;
    else if (scale == 'K' || scale == 'k') return temp - 273.15;
    else return -9999;
}

double fromCelsius(double tempC, char target) {
    if (target == 'C' || target == 'c') return tempC;
    else if (target == 'F' || target == 'f') return tempC * 9 / 5 + 32;
    else if (target == 'K' || target == 'k') return tempC + 273.15;
    else return -9999;
}

void categorize(double tempC) {
    if (tempC < 0) printf("Temperature category: Freezing\nWeather advisory: Wear a jacket!\n");
    else if (tempC < 10) printf("Temperature category: Cold\nWeather advisory: Bring a coat.\n");
    else if (tempC < 25) printf("Temperature category: Comfortable\nWeather advisory: Enjoy your day!\n");
    else if (tempC < 35) printf("Temperature category: Hot\nWeather advisory: Drink lots of water!\n");
    else printf("Temperature category: Extreme Heat\nWeather advisory: Stay indoors!\n");
}

int main() {
    double value, converted;
    char from, to;

    printf("Enter the temperature value: ");
    if (scanf("%lf", &value) != 1) {
        printf("Invalid input.\n");
        return 1;
    }

    printf("Enter the original scale (C, F, or K): ");
    scanf(" %c", &from);

    printf("Enter the scale to convert to (C, F, or K): ");
    scanf(" %c", &to);

    double tempC = toCelsius(value, from);
    if (tempC == -9999) {
        printf("Invalid input scale.\n");
        return 1;
    }

    if (from == 'K' || from == 'k') {
        if (value < 0) {
            printf("Invalid input. Kelvin cannot be negative.\n");
            return 1;
        }
    }

    converted = fromCelsius(tempC, to);
    if (converted == -9999) {
        printf("Invalid target scale.\n");
        return 1;
    }

    printf("Converted temperature: %.2f %c\n", converted, to);
    categorize(fromCelsius(tempC, 'C'));

    return 0;
}
